"use client"
import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { MapPin, Phone, User, Car, RefreshCw } from "lucide-react"

interface Trip {
  id: string
  time: string
  customerName: string
  customerPhone: string
  pickupAddress: string
  dropoffAddress: string
  vehicle: string
  status: "PENDING" | "ACCEPTED" | "IN_PROGRESS" | "COMPLETED" | "CANCELLED"
  fare: string
}

export default function TripAssignments() {
  const [trips, setTrips] = useState<Trip[]>([
    {
      id: "T001",
      time: "2:30 PM",
      customerName: "Sarah Johnson",
      customerPhone: "(555) 123-4567",
      pickupAddress: "123 Main St, Downtown",
      dropoffAddress: "456 Oak Ave, Uptown",
      vehicle: "Lincoln Navigator",
      status: "PENDING",
      fare: "$85.00",
    },
    {
      id: "T002",
      time: "3:15 PM",
      customerName: "Michael Chen",
      customerPhone: "(555) 987-6543",
      pickupAddress: "789 Business Plaza",
      dropoffAddress: "Airport Terminal 1",
      vehicle: "Town Car",
      status: "ACCEPTED",
      fare: "$120.00",
    },
    {
      id: "T003",
      time: "4:00 PM",
      customerName: "Emily Rodriguez",
      customerPhone: "(555) 456-7890",
      pickupAddress: "Hotel Grand Plaza",
      dropoffAddress: "Convention Center",
      vehicle: "Stretch Limousine",
      status: "IN_PROGRESS",
      fare: "$200.00",
    },
    {
      id: "T004",
      time: "5:30 PM",
      customerName: "David Wilson",
      customerPhone: "(555) 321-0987",
      pickupAddress: "Corporate Office Building",
      dropoffAddress: "Residential District",
      vehicle: "Lincoln Navigator",
      status: "COMPLETED",
      fare: "$95.00",
    },
  ])

  const getStatusColor = (status: Trip["status"]) => {
    switch (status) {
      case "PENDING":
        return "bg-yellow-600 text-yellow-100"
      case "ACCEPTED":
        return "bg-blue-600 text-blue-100"
      case "IN_PROGRESS":
        return "bg-green-600 text-green-100"
      case "COMPLETED":
        return "bg-gray-600 text-gray-100"
      case "CANCELLED":
        return "bg-red-600 text-red-100"
      default:
        return "bg-gray-600 text-gray-100"
    }
  }

  const handleStatusUpdate = (tripId: string, newStatus: Trip["status"]) => {
    setTrips(trips.map((trip) => (trip.id === tripId ? { ...trip, status: newStatus } : trip)))
  }

  const handleRefresh = () => {
    // Simulate refresh - in real app, this would fetch new data
    console.log("Refreshing trip assignments...")
  }

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Header */}
      <div className="bg-[#1f1f1f] border-b border-gray-800 p-6">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold mb-2">Trip Assignments</h1>
            <p className="text-gray-400">Manage your assigned trips and update status</p>
          </div>
          <Button onClick={handleRefresh} className="bg-red-600 hover:bg-red-700 text-white">
            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh
          </Button>
        </div>
      </div>

      {/* Trip Cards */}
      <main className="max-w-7xl mx-auto p-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {trips.map((trip) => (
            <Card key={trip.id} className="bg-[#1f1f1f] border-gray-800">
              <CardHeader className="pb-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className="text-xl font-bold text-white">{trip.time}</div>
                    <div className="flex items-center space-x-2">
                      <User className="h-4 w-4 text-gray-400" />
                      <span className="text-white font-semibold">{trip.customerName}</span>
                    </div>
                  </div>
                  <span className={`px-3 py-1 rounded-full text-xs font-semibold ${getStatusColor(trip.status)}`}>
                    {trip.status}
                  </span>
                </div>
                <div className="flex items-center space-x-2 text-gray-400">
                  <Phone className="h-4 w-4" />
                  <span className="text-sm">{trip.customerPhone}</span>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Pickup Location */}
                <div className="flex items-start space-x-3">
                  <div className="p-2 bg-green-600 rounded-lg mt-1">
                    <MapPin className="h-4 w-4 text-white" />
                  </div>
                  <div>
                    <div className="text-sm font-medium text-green-400">Pickup</div>
                    <div className="text-white">{trip.pickupAddress}</div>
                  </div>
                </div>

                {/* Dropoff Location */}
                <div className="flex items-start space-x-3">
                  <div className="p-2 bg-red-600 rounded-lg mt-1">
                    <MapPin className="h-4 w-4 text-white" />
                  </div>
                  <div>
                    <div className="text-sm font-medium text-red-400">Dropoff</div>
                    <div className="text-white">{trip.dropoffAddress}</div>
                  </div>
                </div>

                {/* Vehicle Info */}
                <div className="flex items-center justify-between bg-black rounded-lg p-3">
                  <div className="flex items-center space-x-3">
                    <Car className="h-5 w-5 text-gray-400" />
                    <span className="text-white font-medium">{trip.vehicle}</span>
                  </div>
                  <div className="text-xl font-bold text-red-600">{trip.fare}</div>
                </div>

                {/* Action Buttons */}
                <div className="flex space-x-2 pt-2">
                  {trip.status === "PENDING" && (
                    <>
                      <Button
                        onClick={() => handleStatusUpdate(trip.id, "ACCEPTED")}
                        className="flex-1 bg-green-600 hover:bg-green-700 text-white"
                      >
                        Accept Trip
                      </Button>
                      <Button
                        onClick={() => handleStatusUpdate(trip.id, "CANCELLED")}
                        variant="outline"
                        className="flex-1 border-red-600 text-red-600 hover:bg-red-600 hover:text-white bg-transparent"
                      >
                        Decline
                      </Button>
                    </>
                  )}

                  {trip.status === "ACCEPTED" && (
                    <Button
                      onClick={() => handleStatusUpdate(trip.id, "IN_PROGRESS")}
                      className="w-full bg-blue-600 hover:bg-blue-700 text-white"
                    >
                      Start Trip
                    </Button>
                  )}

                  {trip.status === "IN_PROGRESS" && (
                    <Button
                      onClick={() => handleStatusUpdate(trip.id, "COMPLETED")}
                      className="w-full bg-red-600 hover:bg-red-700 text-white"
                    >
                      Complete Trip
                    </Button>
                  )}

                  {trip.status === "COMPLETED" && (
                    <div className="w-full text-center py-2 text-gray-400 font-medium">Trip Completed</div>
                  )}

                  {trip.status === "CANCELLED" && (
                    <div className="w-full text-center py-2 text-red-400 font-medium">Trip Cancelled</div>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Summary Stats */}
        <div className="mt-8 grid grid-cols-1 md:grid-cols-4 gap-6">
          <Card className="bg-[#1f1f1f] border-gray-800">
            <CardContent className="p-6">
              <div className="text-center">
                <div className="text-2xl font-bold text-yellow-600 mb-2">
                  {trips.filter((t) => t.status === "PENDING").length}
                </div>
                <div className="text-gray-400">Pending</div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-[#1f1f1f] border-gray-800">
            <CardContent className="p-6">
              <div className="text-center">
                <div className="text-2xl font-bold text-blue-600 mb-2">
                  {trips.filter((t) => t.status === "ACCEPTED").length}
                </div>
                <div className="text-gray-400">Accepted</div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-[#1f1f1f] border-gray-800">
            <CardContent className="p-6">
              <div className="text-center">
                <div className="text-2xl font-bold text-green-600 mb-2">
                  {trips.filter((t) => t.status === "IN_PROGRESS").length}
                </div>
                <div className="text-gray-400">In Progress</div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-[#1f1f1f] border-gray-800">
            <CardContent className="p-6">
              <div className="text-center">
                <div className="text-2xl font-bold text-gray-600 mb-2">
                  {trips.filter((t) => t.status === "COMPLETED").length}
                </div>
                <div className="text-gray-400">Completed</div>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}
