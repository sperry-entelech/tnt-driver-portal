"use client"
import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Clock, Car, User } from "lucide-react"

interface ShiftHistory {
  id: string
  date: string
  vehicle: string
  startTime: string
  endTime: string
  startMileage: number
  endMileage: number
  totalMiles: number
  duration: string
}

export default function ShiftManagement() {
  const [isOnDuty, setIsOnDuty] = useState(false)
  const [selectedVehicle, setSelectedVehicle] = useState("")
  const [startMileage, setStartMileage] = useState("")
  const [endMileage, setEndMileage] = useState("")
  const [currentShiftStart, setCurrentShiftStart] = useState<string | null>(null)

  const vehicles = [
    "Lincoln Navigator - LN001",
    "Lincoln Town Car - TC002",
    "Cadillac Escalade - CE003",
    "Mercedes S-Class - MS004",
    "BMW 7 Series - BM005",
    "Lincoln Continental - LC006",
    "Chrysler 300 - CH007",
    "Lincoln MKT - MK008",
  ]

  const shiftHistory: ShiftHistory[] = [
    {
      id: "1",
      date: "2024-01-15",
      vehicle: "Lincoln Navigator - LN001",
      startTime: "08:00 AM",
      endTime: "06:00 PM",
      startMileage: 45230,
      endMileage: 45387,
      totalMiles: 157,
      duration: "10h 0m",
    },
    {
      id: "2",
      date: "2024-01-14",
      vehicle: "Lincoln Town Car - TC002",
      startTime: "09:00 AM",
      endTime: "05:30 PM",
      startMileage: 32145,
      endMileage: 32289,
      totalMiles: 144,
      duration: "8h 30m",
    },
    {
      id: "3",
      date: "2024-01-13",
      vehicle: "Cadillac Escalade - CE003",
      startTime: "07:30 AM",
      endTime: "07:00 PM",
      startMileage: 28901,
      endMileage: 29078,
      totalMiles: 177,
      duration: "11h 30m",
    },
  ]

  const handleStartShift = () => {
    if (!selectedVehicle || !startMileage) {
      alert("Please select a vehicle and enter starting mileage")
      return
    }
    setIsOnDuty(true)
    setCurrentShiftStart(new Date().toLocaleTimeString())
  }

  const handleEndShift = () => {
    if (!endMileage) {
      alert("Please enter ending mileage")
      return
    }
    setIsOnDuty(false)
    setCurrentShiftStart(null)
    setSelectedVehicle("")
    setStartMileage("")
    setEndMileage("")
  }

  return (
    <div className="min-h-screen bg-black text-white p-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Shift Management</h1>
          <p className="text-gray-400">Manage your work shifts and track vehicle usage</p>
        </div>

        {/* Current Shift Status */}
        <Card className="bg-[#1f1f1f] border-gray-800 mb-8">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="p-2 bg-red-600 rounded-lg">
                  <Clock className="h-6 w-6 text-white" />
                </div>
                <div>
                  <h2 className="text-xl font-semibold text-white">Current Shift Status</h2>
                  <p className="text-sm text-gray-400">Track your current work session</p>
                </div>
              </div>
              <div
                className={`px-4 py-2 rounded-full font-semibold ${
                  isOnDuty ? "bg-green-600 text-white" : "bg-gray-600 text-gray-300"
                }`}
              >
                {isOnDuty ? "ON DUTY" : "OFF DUTY"}
              </div>
            </div>
          </CardHeader>
          <CardContent>
            {isOnDuty && currentShiftStart && (
              <div className="mb-4 p-4 bg-green-900/20 border border-green-600 rounded-lg">
                <div className="flex items-center space-x-2 mb-2">
                  <User className="h-4 w-4 text-green-400" />
                  <span className="text-green-400 font-medium">Shift Started: {currentShiftStart}</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Car className="h-4 w-4 text-green-400" />
                  <span className="text-green-400">Vehicle: {selectedVehicle}</span>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Shift Controls */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
          {/* Vehicle Selection & Mileage */}
          <Card className="bg-[#1f1f1f] border-gray-800">
            <CardHeader className="pb-3">
              <div className="flex items-center space-x-3">
                <div className="p-2 bg-red-600 rounded-lg">
                  <Car className="h-6 w-6 text-white" />
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-white">Vehicle & Mileage</h3>
                  <p className="text-sm text-gray-400">Select vehicle and record mileage</p>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <label className="text-sm font-medium text-gray-300">Select Vehicle</label>
                <Select value={selectedVehicle} onValueChange={setSelectedVehicle} disabled={isOnDuty}>
                  <SelectTrigger className="h-12 bg-black border-gray-600 text-white focus:border-red-600">
                    <SelectValue placeholder="Choose your vehicle" />
                  </SelectTrigger>
                  <SelectContent className="bg-[#1f1f1f] border-gray-600">
                    {vehicles.map((vehicle) => (
                      <SelectItem key={vehicle} value={vehicle} className="text-white hover:bg-gray-700">
                        {vehicle}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-300">Starting Mileage</label>
                  <Input
                    type="number"
                    value={startMileage}
                    onChange={(e) => setStartMileage(e.target.value)}
                    className="h-12 bg-black border-gray-600 text-white placeholder:text-gray-500 focus:border-red-600"
                    placeholder="Enter miles"
                    disabled={isOnDuty}
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-300">Ending Mileage</label>
                  <Input
                    type="number"
                    value={endMileage}
                    onChange={(e) => setEndMileage(e.target.value)}
                    className="h-12 bg-black border-gray-600 text-white placeholder:text-gray-500 focus:border-red-600"
                    placeholder="Enter miles"
                    disabled={!isOnDuty}
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Shift Actions */}
          <Card className="bg-[#1f1f1f] border-gray-800">
            <CardHeader className="pb-3">
              <div className="flex items-center space-x-3">
                <div className="p-2 bg-red-600 rounded-lg">
                  <Clock className="h-6 w-6 text-white" />
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-white">Shift Actions</h3>
                  <p className="text-sm text-gray-400">Start or end your work shift</p>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              {!isOnDuty ? (
                <Button
                  onClick={handleStartShift}
                  className="w-full h-14 bg-red-600 hover:bg-red-700 text-white font-semibold text-lg"
                >
                  Start Shift
                </Button>
              ) : (
                <Button
                  onClick={handleEndShift}
                  className="w-full h-14 bg-red-600 hover:bg-red-700 text-white font-semibold text-lg"
                >
                  End Shift
                </Button>
              )}

              <div className="text-center text-sm text-gray-400">
                {!isOnDuty
                  ? "Select a vehicle and enter starting mileage to begin your shift"
                  : "Enter ending mileage and click End Shift when you're done"}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Shift History */}
        <Card className="bg-[#1f1f1f] border-gray-800">
          <CardHeader className="pb-3">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-red-600 rounded-lg">
                <Clock className="h-6 w-6 text-white" />
              </div>
              <div>
                <h3 className="text-lg font-semibold text-white">Shift History</h3>
                <p className="text-sm text-gray-400">Your recent work shifts</p>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {shiftHistory.map((shift) => (
                <Card key={shift.id} className="bg-black border-gray-700">
                  <CardContent className="p-4">
                    <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                      <div>
                        <div className="text-sm text-gray-400">Date</div>
                        <div className="font-medium text-white">{shift.date}</div>
                      </div>
                      <div>
                        <div className="text-sm text-gray-400">Vehicle</div>
                        <div className="font-medium text-white">{shift.vehicle}</div>
                      </div>
                      <div>
                        <div className="text-sm text-gray-400">Time</div>
                        <div className="font-medium text-white">
                          {shift.startTime} - {shift.endTime}
                        </div>
                        <div className="text-sm text-gray-400">Duration: {shift.duration}</div>
                      </div>
                      <div>
                        <div className="text-sm text-gray-400">Mileage</div>
                        <div className="font-medium text-white">
                          {shift.startMileage.toLocaleString()} - {shift.endMileage.toLocaleString()}
                        </div>
                        <div className="text-sm text-red-400">Total: {shift.totalMiles} miles</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
