"use client"

import { useState, useMemo } from "react"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { User, Phone, Clock, Car, Search, RefreshCw } from "lucide-react"

interface Driver {
  id: string
  name: string
  phone: string
  availability: string
  restrictions: string
  status: "available" | "on-duty" | "off-duty"
}

const driversData: Driver[] = [
  {
    id: "1",
    name: "Aric Coleman",
    phone: "804.219.7782",
    availability: "Nights and Weekends",
    restrictions: "Everything",
    status: "available",
  },
  {
    id: "2",
    name: "Brett Allen",
    phone: "804.512.2424",
    availability: "Nights and Weekends",
    restrictions: "Not Bus",
    status: "on-duty",
  },
  {
    id: "3",
    name: 'Matthew Irving "Bubba"',
    phone: "804.513.3969",
    availability: "Weekends + Limo Bus",
    restrictions: "Everything",
    status: "available",
  },
  {
    id: "4",
    name: "Carolyn Helmick",
    phone: "804.845.7386",
    availability: "Nights and Weekends",
    restrictions: "Everything",
    status: "off-duty",
  },
  {
    id: "5",
    name: "Dennis Berman",
    phone: "804.380.1271",
    availability: "Anytime (TransMedics runs)",
    restrictions: "Not Bus",
    status: "on-duty",
  },
  {
    id: "6",
    name: "Derek Wilson",
    phone: "804.787.0871",
    availability: "Weekends",
    restrictions: "Not Bus",
    status: "available",
  },
  {
    id: "7",
    name: "Harold Gordon",
    phone: "804.218.9192",
    availability: "Weekdays after 6 pm and Weekends",
    restrictions: "Not Bus",
    status: "off-duty",
  },
  {
    id: "8",
    name: "Jim Johnston",
    phone: "804.437.0368",
    availability: "Anytime",
    restrictions: "Not Bus",
    status: "available",
  },
  {
    id: "9",
    name: "Kory Hummer Jr",
    phone: "804.591.7837",
    availability: "Most Anytime",
    restrictions: "Not Bus",
    status: "on-duty",
  },
]

export default function ViewAllDrivers() {
  const [searchTerm, setSearchTerm] = useState("")
  const [availabilityFilter, setAvailabilityFilter] = useState("")
  const [restrictionFilter, setRestrictionFilter] = useState("")

  const filteredDrivers = useMemo(() => {
    return driversData.filter((driver) => {
      const matchesSearch =
        driver.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        driver.phone.includes(searchTerm) ||
        driver.availability.toLowerCase().includes(searchTerm.toLowerCase()) ||
        driver.restrictions.toLowerCase().includes(searchTerm.toLowerCase())

      const matchesAvailability =
        availabilityFilter === "" || driver.availability.toLowerCase().includes(availabilityFilter.toLowerCase())

      const matchesRestriction =
        restrictionFilter === "" || driver.restrictions.toLowerCase().includes(restrictionFilter.toLowerCase())

      return matchesSearch && matchesAvailability && matchesRestriction
    })
  }, [searchTerm, availabilityFilter, restrictionFilter])

  const getStatusColor = (status: string) => {
    switch (status) {
      case "available":
        return "bg-green-600 hover:bg-green-700"
      case "on-duty":
        return "bg-blue-600 hover:bg-blue-700"
      case "off-duty":
        return "bg-gray-600 hover:bg-gray-700"
      default:
        return "bg-gray-600 hover:bg-gray-700"
    }
  }

  const getStatusText = (status: string) => {
    switch (status) {
      case "available":
        return "AVAILABLE"
      case "on-duty":
        return "ON DUTY"
      case "off-duty":
        return "OFF DUTY"
      default:
        return "UNKNOWN"
    }
  }

  const clearFilters = () => {
    setSearchTerm("")
    setAvailabilityFilter("")
    setRestrictionFilter("")
  }

  return (
    <div className="min-h-screen bg-black text-white p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold mb-2">All Drivers</h1>
            <p className="text-gray-400">Manage and search driver information</p>
          </div>
          <Button onClick={() => window.location.reload()} className="bg-red-600 hover:bg-red-700 text-white">
            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh
          </Button>
        </div>

        {/* Search and Filters */}
        <Card className="bg-[#1f1f1f] border-gray-800 mb-6">
          <CardHeader>
            <h3 className="text-lg font-semibold text-white">Search & Filter Drivers</h3>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Search drivers..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 bg-black border-gray-600 text-white placeholder:text-gray-500 focus:border-red-600"
                />
              </div>
              <Input
                placeholder="Filter by availability..."
                value={availabilityFilter}
                onChange={(e) => setAvailabilityFilter(e.target.value)}
                className="bg-black border-gray-600 text-white placeholder:text-gray-500 focus:border-red-600"
              />
              <Input
                placeholder="Filter by restrictions..."
                value={restrictionFilter}
                onChange={(e) => setRestrictionFilter(e.target.value)}
                className="bg-black border-gray-600 text-white placeholder:text-gray-500 focus:border-red-600"
              />
              <Button
                onClick={clearFilters}
                variant="outline"
                className="border-gray-600 text-gray-300 hover:bg-gray-800 bg-transparent"
              >
                Clear Filters
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Driver Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <Card className="bg-[#1f1f1f] border-gray-800">
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-red-600 mb-1">{driversData.length}</div>
              <div className="text-sm text-gray-400">Total Drivers</div>
            </CardContent>
          </Card>
          <Card className="bg-[#1f1f1f] border-gray-800">
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-green-600 mb-1">
                {driversData.filter((d) => d.status === "available").length}
              </div>
              <div className="text-sm text-gray-400">Available</div>
            </CardContent>
          </Card>
          <Card className="bg-[#1f1f1f] border-gray-800">
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-blue-600 mb-1">
                {driversData.filter((d) => d.status === "on-duty").length}
              </div>
              <div className="text-sm text-gray-400">On Duty</div>
            </CardContent>
          </Card>
          <Card className="bg-[#1f1f1f] border-gray-800">
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-gray-600 mb-1">
                {driversData.filter((d) => d.status === "off-duty").length}
              </div>
              <div className="text-sm text-gray-400">Off Duty</div>
            </CardContent>
          </Card>
        </div>

        {/* Driver Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredDrivers.map((driver) => (
            <Card key={driver.id} className="bg-[#1f1f1f] border-gray-800 hover:border-red-600 transition-colors">
              <CardHeader className="pb-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className="p-2 bg-red-600 rounded-lg">
                      <User className="h-5 w-5 text-white" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-white">{driver.name}</h3>
                      <div className="flex items-center space-x-1 text-sm text-gray-400">
                        <Phone className="h-3 w-3" />
                        <span>{driver.phone}</span>
                      </div>
                    </div>
                  </div>
                  <Badge className={`${getStatusColor(driver.status)} text-white text-xs`}>
                    {getStatusText(driver.status)}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-start space-x-2">
                  <Clock className="h-4 w-4 text-gray-400 mt-0.5 flex-shrink-0" />
                  <div>
                    <div className="text-sm font-medium text-gray-300">Availability</div>
                    <div className="text-sm text-gray-400">{driver.availability}</div>
                  </div>
                </div>
                <div className="flex items-start space-x-2">
                  <Car className="h-4 w-4 text-gray-400 mt-0.5 flex-shrink-0" />
                  <div>
                    <div className="text-sm font-medium text-gray-300">Vehicle Restrictions</div>
                    <div className="text-sm text-gray-400">{driver.restrictions}</div>
                  </div>
                </div>
                <div className="pt-2">
                  <Button className="w-full bg-red-600 hover:bg-red-700 text-white" size="sm">
                    Contact Driver
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {filteredDrivers.length === 0 && (
          <Card className="bg-[#1f1f1f] border-gray-800 mt-6">
            <CardContent className="p-8 text-center">
              <User className="h-12 w-12 text-gray-600 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-gray-300 mb-2">No drivers found</h3>
              <p className="text-gray-400">Try adjusting your search criteria or clear the filters.</p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}
