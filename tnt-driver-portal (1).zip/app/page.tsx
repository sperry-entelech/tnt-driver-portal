"use client"

import type React from "react"
import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Checkbox } from "@/components/ui/checkbox"
import { User, Clock, Car, Home, HelpCircle, CheckCircle, AlertCircle } from "lucide-react"
import Image from "next/image"
import ShiftManagement from "@/components/shift-management"
import TripAssignments from "@/components/trip-assignments"
import ViewAllDrivers from "@/components/view-all-drivers"

export default function TNTDriverPortal() {
  const [isLoggedIn, setIsLoggedIn] = useState(true)
  const [currentView, setCurrentView] = useState("dashboard")
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [rememberMe, setRememberMe] = useState(false)
  const [showConfirmDialog, setShowConfirmDialog] = useState(false)
  const [confirmAction, setConfirmAction] = useState<() => void>(() => {})
  const [confirmMessage, setConfirmMessage] = useState("")
  const [successMessage, setSuccessMessage] = useState("")

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault()
    if (email && password) {
      setIsLoggedIn(true)
      setSuccessMessage("Welcome! You have successfully signed in.")
      setTimeout(() => setSuccessMessage(""), 5000)
    }
  }

  const confirmLogout = () => {
    setConfirmMessage("Are you sure you want to sign out of the TNT Driver Portal?")
    setConfirmAction(() => () => {
      setIsLoggedIn(false)
      setCurrentView("dashboard")
      setEmail("")
      setPassword("")
      setRememberMe(false)
      setShowConfirmDialog(false)
      setSuccessMessage("You have been signed out successfully.")
      setTimeout(() => setSuccessMessage(""), 5000)
    })
    setShowConfirmDialog(true)
  }

  const handleNavigation = (view: string) => {
    setCurrentView(view)
    setSuccessMessage("")
  }

  const getViewTitle = () => {
    switch (currentView) {
      case "shift-management":
        return "My Work Schedule"
      case "trip-assignments":
        return "My Trips"
      case "view-drivers":
        return "Other Drivers"
      default:
        return "My Dashboard"
    }
  }

  const renderCurrentView = () => {
    switch (currentView) {
      case "shift-management":
        return <ShiftManagement />
      case "trip-assignments":
        return <TripAssignments />
      case "view-drivers":
        return <ViewAllDrivers />
      default:
        return (
          <div className="space-y-12">
            {/* Welcome Section */}
            <div className="text-center bg-gray-900 rounded-2xl p-12 shadow-lg">
              <h2 className="text-4xl font-bold text-white mb-4">Welcome Back!</h2>
              <p className="text-2xl text-gray-300">Choose what you'd like to do today</p>
            </div>

            {/* Main Navigation - Large Buttons */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <Card
                className="bg-gray-900 border-2 border-gray-700 hover:border-green-500 hover:shadow-xl transition-all cursor-pointer p-8"
                onClick={() => handleNavigation("shift-management")}
              >
                <CardContent className="text-center space-y-6">
                  <div className="flex justify-center">
                    <div className="p-6 bg-green-900 rounded-full">
                      <Clock className="h-16 w-16 text-green-400" />
                    </div>
                  </div>
                  <div>
                    <h3 className="text-3xl font-bold text-white mb-3">My Work Schedule</h3>
                    <p className="text-xl text-gray-300">Start or end your shift, track your hours</p>
                  </div>
                </CardContent>
              </Card>

              <Card
                className="bg-gray-900 border-2 border-gray-700 hover:border-blue-500 hover:shadow-xl transition-all cursor-pointer p-8"
                onClick={() => handleNavigation("trip-assignments")}
              >
                <CardContent className="text-center space-y-6">
                  <div className="flex justify-center">
                    <div className="p-6 bg-blue-900 rounded-full">
                      <Car className="h-16 w-16 text-blue-400" />
                    </div>
                  </div>
                  <div>
                    <h3 className="text-3xl font-bold text-white mb-3">My Trips</h3>
                    <p className="text-xl text-gray-300">View your assigned rides and pickups</p>
                  </div>
                </CardContent>
              </Card>

              <Card
                className="bg-gray-900 border-2 border-gray-700 hover:border-purple-500 hover:shadow-xl transition-all cursor-pointer p-8"
                onClick={() => handleNavigation("view-drivers")}
              >
                <CardContent className="text-center space-y-6">
                  <div className="flex justify-center">
                    <div className="p-6 bg-purple-900 rounded-full">
                      <User className="h-16 w-16 text-purple-400" />
                    </div>
                  </div>
                  <div>
                    <h3 className="text-3xl font-bold text-white mb-3">Other Drivers</h3>
                    <p className="text-xl text-gray-300">See who else is working today</p>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gray-900 border-2 border-gray-700 p-8">
                <CardContent className="text-center space-y-6">
                  <div className="flex justify-center">
                    <div className="p-6 bg-orange-900 rounded-full">
                      <HelpCircle className="h-16 w-16 text-orange-400" />
                    </div>
                  </div>
                  <div>
                    <h3 className="text-3xl font-bold text-white mb-3">Need Help?</h3>
                    <p className="text-xl text-gray-300 mb-6">Call the office if you have questions</p>
                    <Button className="h-16 px-8 text-xl font-semibold bg-orange-600 hover:bg-orange-700 text-white rounded-xl">
                      Call Office
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Today's Summary */}
            <div className="bg-gray-900 rounded-2xl p-8 shadow-lg">
              <h3 className="text-3xl font-bold text-white mb-8 text-center">Today's Summary</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                <div className="text-center p-6 bg-green-900 rounded-xl">
                  <div className="text-5xl font-bold text-green-400 mb-3">12</div>
                  <div className="text-2xl text-gray-300">Trips Completed</div>
                </div>

                <div className="text-center p-6 bg-blue-900 rounded-xl">
                  <div className="text-5xl font-bold text-blue-400 mb-3">8.5</div>
                  <div className="text-2xl text-gray-300">Hours Worked</div>
                </div>

                <div className="text-center p-6 bg-purple-900 rounded-xl">
                  <div className="text-5xl font-bold text-purple-400 mb-3">$485</div>
                  <div className="text-2xl text-gray-300">Money Earned</div>
                </div>
              </div>
            </div>
          </div>
        )
    }
  }

  const ConfirmDialog = () =>
    showConfirmDialog && (
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
        <Card className="bg-white max-w-md w-full">
          <CardHeader className="text-center pb-4">
            <AlertCircle className="h-16 w-16 text-orange-500 mx-auto mb-4" />
            <h3 className="text-2xl font-bold text-gray-900">Confirm Action</h3>
          </CardHeader>
          <CardContent className="space-y-6">
            <p className="text-xl text-gray-700 text-center">{confirmMessage}</p>
            <div className="flex space-x-4">
              <Button
                onClick={() => setShowConfirmDialog(false)}
                className="flex-1 h-16 text-xl font-semibold bg-gray-500 hover:bg-gray-600 text-white rounded-xl"
              >
                Cancel
              </Button>
              <Button
                onClick={confirmAction}
                className="flex-1 h-16 text-xl font-semibold bg-red-600 hover:bg-red-700 text-white rounded-xl"
              >
                Yes, Continue
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    )

  const SuccessMessage = () =>
    successMessage && (
      <div className="fixed top-4 right-4 z-50">
        <Card className="bg-green-100 border-2 border-green-500">
          <CardContent className="flex items-center space-x-3 p-4">
            <CheckCircle className="h-8 w-8 text-green-600" />
            <p className="text-lg font-semibold text-green-800">{successMessage}</p>
          </CardContent>
        </Card>
      </div>
    )

  if (isLoggedIn) {
    return (
      <div className="min-h-screen bg-black">
        <ConfirmDialog />
        <SuccessMessage />

        <header className="bg-gray-900 border-b-4 border-gray-700 p-6 shadow-lg">
          <div className="max-w-7xl mx-auto">
            {/* Top Row - Logo and Sign Out */}
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center space-x-6">
                <Image
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/tnt%20logo.jpg-0nOdMYbCPVo0wVE6e5IXucJH5VJqRb.jpeg"
                  alt="TNT Limousine Logo"
                  width={80}
                  height={80}
                  className="rounded-lg"
                />
                <div>
                  <h1 className="text-4xl font-bold text-white">TNT Driver Portal</h1>
                </div>
              </div>
              <Button
                onClick={confirmLogout}
                className="h-16 px-8 text-xl font-semibold bg-red-600 hover:bg-red-700 text-white rounded-xl"
              >
                Sign Out
              </Button>
            </div>

            {/* Navigation Tabs */}
            <div className="flex flex-wrap gap-4">
              <Button
                onClick={() => handleNavigation("dashboard")}
                className={`h-16 px-8 text-xl font-semibold rounded-xl flex items-center space-x-3 ${
                  currentView === "dashboard" ? "bg-blue-600 text-white" : "bg-gray-700 text-gray-200 hover:bg-gray-600"
                }`}
              >
                <Home className="h-6 w-6" />
                <span>Home</span>
              </Button>

              <Button
                onClick={() => handleNavigation("shift-management")}
                className={`h-16 px-8 text-xl font-semibold rounded-xl flex items-center space-x-3 ${
                  currentView === "shift-management"
                    ? "bg-green-600 text-white"
                    : "bg-gray-700 text-gray-200 hover:bg-gray-600"
                }`}
              >
                <Clock className="h-6 w-6" />
                <span>My Schedule</span>
              </Button>

              <Button
                onClick={() => handleNavigation("trip-assignments")}
                className={`h-16 px-8 text-xl font-semibold rounded-xl flex items-center space-x-3 ${
                  currentView === "trip-assignments"
                    ? "bg-blue-600 text-white"
                    : "bg-gray-700 text-gray-200 hover:bg-gray-600"
                }`}
              >
                <Car className="h-6 w-6" />
                <span>My Trips</span>
              </Button>

              <Button
                onClick={() => handleNavigation("view-drivers")}
                className={`h-16 px-8 text-xl font-semibold rounded-xl flex items-center space-x-3 ${
                  currentView === "view-drivers"
                    ? "bg-purple-600 text-white"
                    : "bg-gray-700 text-gray-200 hover:bg-gray-600"
                }`}
              >
                <User className="h-6 w-6" />
                <span>Other Drivers</span>
              </Button>
            </div>

            {/* Breadcrumb */}
            <div className="mt-6 p-4 bg-gray-800 rounded-xl">
              <p className="text-xl text-gray-200">
                <span className="font-semibold">You are here:</span> {getViewTitle()}
              </p>
            </div>
          </div>
        </header>

        <main className="max-w-7xl mx-auto p-8">{renderCurrentView()}</main>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-100 flex items-center justify-center p-8">
      <SuccessMessage />
      <Card className="w-full max-w-lg bg-white border-2 border-gray-300 shadow-xl">
        <CardHeader className="text-center pb-8">
          <div className="flex justify-center mb-8">
            <Image
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/tnt%20logo.jpg-0nOdMYbCPVo0wVE6e5IXucJH5VJqRb.jpeg"
              alt="TNT Limousine Logo"
              width={150}
              height={150}
              className="rounded-lg"
            />
          </div>
          <h1 className="text-4xl font-bold text-gray-900 mb-4">TNT Driver Portal</h1>
          <p className="text-2xl text-gray-700">Please sign in to continue</p>
        </CardHeader>

        <CardContent className="p-8">
          <form onSubmit={handleLogin} className="space-y-8">
            <div className="space-y-3">
              <label htmlFor="email" className="text-xl font-semibold text-gray-900 block">
                Your Email Address
              </label>
              <Input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="h-16 text-xl bg-white border-2 border-gray-400 text-gray-900 placeholder:text-gray-500 focus:border-blue-600 focus:ring-blue-600 rounded-xl"
                placeholder="Enter your email here"
                required
              />
            </div>

            <div className="space-y-3">
              <label htmlFor="password" className="text-xl font-semibold text-gray-900 block">
                Your Password
              </label>
              <Input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="h-16 text-xl bg-white border-2 border-gray-400 text-gray-900 placeholder:text-gray-500 focus:border-blue-600 focus:ring-blue-600 rounded-xl"
                placeholder="Enter your password here"
                required
              />
            </div>

            <div className="flex flex-col space-y-6">
              <div className="flex items-center space-x-4">
                <Checkbox
                  id="remember"
                  checked={rememberMe}
                  onCheckedChange={(checked) => setRememberMe(checked as boolean)}
                  className="w-6 h-6 border-2 border-gray-400 data-[state=checked]:bg-blue-600 data-[state=checked]:border-blue-600"
                />
                <label htmlFor="remember" className="text-xl text-gray-900">
                  Keep me signed in
                </label>
              </div>

              <button type="button" className="text-xl text-blue-600 hover:text-blue-800 font-semibold text-left">
                Forgot your password? Click here for help
              </button>
            </div>

            <Button
              type="submit"
              className="w-full h-20 text-2xl font-bold bg-green-600 hover:bg-green-700 text-white rounded-xl"
            >
              Sign In to Portal
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  )
}
